getImgSize.py -> takes image size of all images

csv2txt.py -> takes annotation info from csv for each image and convert it to txt. Also, normalize bounding boxes of each image.

resImgsize.py -> resize all images to a common width and height.

splitter.py -> splits dataset to train, test and validation set